var config = {
    map: {
        '*': {
            bxslider: 'Cccc_Profile/js/bxslider'
        }
    }
};